import requests
import json
import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from datetime import datetime

class Cabin():
	def __init__(self, data):
		self.id = int(data['ID'])
		self.obs = data['Observaciones']
		self.price = int(data['Precio'])

class App(QMainWindow):
	def __init__(self):
		super().__init__()
		self.setWindowTitle("Igmaca")
		self.setGeometry(0,0,600,600)

		self.central_wid = QWidget()
		self.stacked = QStackedLayout()

		
		self.tabs = Tabs(self)
		self.add_res = AddReserve(self)
		self.conf = Confirmation(self)

		self.tabs.cal_tab.button.clicked.connect(self.to_add_res)
		self.add_res.save.clicked.connect(self.save_res)
		self.add_res.cancel.clicked.connect(self.to_tabs)
		self.conf.button.clicked.connect(self.to_tabs)
		
		self.stacked.addWidget(self.tabs)
		self.stacked.addWidget(self.add_res)
		self.stacked.addWidget(self.conf)

		self.central_wid.setLayout(self.stacked)
		self.setCentralWidget(self.central_wid)
	
		self.conf.hide()
		self.add_res.hide()
		self.show()

	def to_add_res(self):
		self.tabs.hide()
		self.add_res.show()

	def to_tabs(self):
		print('asd')
		self.conf.hide()
		self.add_res.hide()
		self.tabs.show()

	def save_res(self):
		rut = self.add_res.client_edit.text() 
		chin = self.add_res.date1
		chout = self.add_res.date2
		precio = str(self.add_res.price)
		c1 = '1' if self.add_res.c1.isChecked() else '0'
		c2 = '2' if self.add_res.c2.isChecked() else '0'
		c3 = '3' if self.add_res.c3.isChecked() else '0'
		header = {'content-type': 'application/json'}
		payload = {"RUT":rut, "in":chin, "out":chout, "costo":precio, "c1":c1, "c2":c2, "c3":c3, "pagado":"0"}
		r = requests.post('http://127.0.0.1:5003/reservas', data=json.dumps(payload), headers=header)

		self.add_res.hide()
		self.conf.show()


class Tabs(QWidget):

	def __init__(self, *args, **kwargs):
		super(QWidget, self).__init__(*args, **kwargs)
		self.layout = QVBoxLayout(self)

		# create tabs
		self.tabs = QTabWidget()
		self.cal_tab = CalWindow()
		self.cli_tab = QWidget()
		self.cab_tab = QWidget()
		self.tabs.resize(300,200)
		self.tabs.addTab(self.cal_tab, "Calendario")
		self.tabs.addTab(self.cli_tab, "Clientes")
		self.tabs.addTab(self.cab_tab, "Cabanas")

		self.layout.addWidget(self.tabs)
		self.setLayout(self.layout)
		

class CalWindow(QWidget):
	def __init__(self, *args, **kwargs):
		super(QWidget, self).__init__(*args, **kwargs)
		self.layout = QVBoxLayout(self)

		self.cal = QCalendarWidget()
		self.cal.setGridVisible(True)
		#cal.move(20,20)
		#cal.clicked[QtCore.QDate].connect(self.showDate)

		self.button = QPushButton( "Agregar Reserva")
		#self.button.move(100,300)
		self.layout.addWidget(self.cal)
		self.layout.addWidget(self.button)
		self.setLayout(self.layout)

class AddReserve(QWidget):
	def __init__(self, *args, **kwargs):
		super(QWidget, self).__init__(*args, **kwargs)
		self.resize(600, 600)
		self.client_label = QLabel("Cliente", self)
		self.client_edit = QLineEdit(self)
		self.client_label.move(20,22)
		self.client_edit.move(100, 20)

		self.cab_label = QLabel("Cabanas", self)
		self.c1 = QCheckBox("1", self)
		self.c2 = QCheckBox("2", self)
		self.c3 = QCheckBox("3", self)
		self.cab_label.move(20, 70)
		self.c1.move(100, 70)
		self.c2.move(150, 70)
		self.c3.move(200, 70)

		self.checkin_lbl = QLabel("Chek-in", self)
		self.checkin = QCalendarWidget(self)
		self.checkin_lbl.move(20, 120)
		self.checkin.resize(210,200)
		self.checkin.move(20, 140)

		self.checkout_lbl = QLabel("Chek-out", self)
		self.checkout = QCalendarWidget(self)
		self.checkout_lbl.move(260, 120)
		self.checkout.resize(210,200)
		self.checkout.move(260, 140)

		self.sale_lbl = QLabel("Descuento(%)", self)
		self.sale = QLineEdit(self)
		self.sale.setText("0")
		self.sale_lbl.move(20, 360)
		self.sale.move (140, 360)

		self.price = 0
		self.price_lbl = QLabel("Precio: ", self)
		self.price_lbl.move(50, 390)
		self.price_lbl.resize(100,30)

		self.calc_price = QPushButton("Calcular precio", self)
		self.calc_price.clicked.connect(self.calcPrice)
		self. calc_price.move(20, 420)

		self.cancel = QPushButton("Cancelar", self)
		self.cancel.move(200,420)

		self.save = QPushButton("Guardar", self)
		self.save.move(400, 420)

		self.error = QLabel("", self)
		self.error.resize(300,30)
		self.error.move(20,500)
		self.error.setStyleSheet("color:red")
		
	def calcPrice(self):
		global cabins
		self.date1 = self.checkin.selectedDate().toString(Qt.ISODate)
		self.date2 = self.checkout.selectedDate().toString(Qt.ISODate)
		r = requests.get('http://127.0.0.1:5003/disponible/{}/{}'.format(self.date1, self.date2))
		r = r.json()['data'][0]
		p = 0
		if self.c1.isChecked():
			if r['c1'] in {None, 0}:
				p += cabins[0].price
			else:
				self.error.setText("No hay disponiblidad")
				return
		if self.c2.isChecked():
			if r['c2'] in {None, 0}:
				p += cabins[1].price
			else:
				self.error.setText("No hay disponiblidad")
				return
		if self.c3.isChecked():
			if r['c3'] in {None, 0}:
				p += cabins[2].price
			else:
				self.error.setText("No hay disponiblidad")
				return
			
		self.error.setText("")

		dateformat = "%Y-%m-%d"
		days = datetime.strptime(self.date2, dateformat) - datetime.strptime(self.date1, dateformat)
		desc = self.sale.text()
		self.price = int(days.days * p * (1 - int(desc)/100.0))
		self.price_lbl.setText("Precio: ${}".format(self.price))
		
		

class Confirmation(QWidget):
	def __init__(self, *args, **kwargs):
		super(QWidget, self).__init__(*args, **kwargs)
		self.resize(600,600)
		self.mess = QLabel("La reserva se ha guardado correctamente",self)
		self.mess.move(100,50)

		self.button = QPushButton("Aceptar", self)
		self.button.move(200,300)
		

def rtest():
	r = requests.get('http://127.0.0.1:5003/usuarios')
	print(r.json()['data'])


rcabins = requests.get('http://127.0.0.1:5003/cabanas').json()['data']
cabins = [Cabin(rcabins[0]), Cabin(rcabins[1]), Cabin(rcabins[2])]

app = QApplication(sys.argv)
window = App()
window.show()

app.exec_()
